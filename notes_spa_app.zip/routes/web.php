<?php

use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::middleware(['auth', 'verified'])->get('/notes', function () {
    return Inertia::render('Notes');
})->name('notes');
