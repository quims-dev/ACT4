<template>
  <div>
    <h1 class="text-2xl font-bold mb-4">My Notes</h1>
    <form @submit.prevent="saveNote">
      <input v-model="form.title" placeholder="Title" class="border rounded p-2 w-full mb-2">
      <textarea v-model="form.content" placeholder="Content" class="border rounded p-2 w-full mb-2"></textarea>
      <button class="bg-blue-500 text-white px-4 py-2 rounded">Save Note</button>
    </form>

    <div v-for="note in notes" :key="note.id" class="border p-4 mt-4 rounded">
      <h2 class="text-lg font-bold">{{ note.title }}</h2>
      <p>{{ note.content }}</p>
      <button @click="editNote(note)" class="text-blue-500">Edit</button>
      <button @click="deleteNote(note.id)" class="text-red-500 ml-2">Delete</button>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const notes = ref([])
const form = ref({
  id: null,
  title: '',
  content: ''
})

const fetchNotes = async () => {
  const response = await axios.get('/api/notes')
  notes.value = response.data
}

const saveNote = async () => {
  if (form.value.id) {
    await axios.put(`/api/notes/${form.value.id}`, form.value)
  } else {
    await axios.post('/api/notes', form.value)
  }
  form.value = { id: null, title: '', content: '' }
  fetchNotes()
}

const editNote = (note) => {
  form.value = { ...note }
}

const deleteNote = async (id) => {
  await axios.delete(`/api/notes/${id}`)
  fetchNotes()
}

onMounted(() => {
  fetchNotes()
})
</script>
